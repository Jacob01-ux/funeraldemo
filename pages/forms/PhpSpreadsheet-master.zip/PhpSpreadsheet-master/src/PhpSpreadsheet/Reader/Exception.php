<?php

namespace PhpSpreadsheetmaster\src\PhpSpreadsheet\Reader;

use PhpSpreadsheetmaster\src\PhpSpreadsheet\Exception as PhpSpreadsheetException;

class Exception extends PhpSpreadsheetException
{
}
