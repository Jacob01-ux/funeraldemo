<?php

namespace PhpSpreadsheetmaster\src\PhpSpreadsheet\Writer;

use PhpSpreadsheetmaster\src\PhpSpreadsheet\Exception as PhpSpreadsheetException;

class Exception extends PhpSpreadsheetException
{
}
