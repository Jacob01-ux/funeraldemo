<?php

namespace PhpSpreadsheetmaster\src\PhpSpreadsheet;

class Exception extends \Exception
{
}
