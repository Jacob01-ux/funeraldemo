<?php

namespace PhpSpreadsheetmaster\src\PhpSpreadsheet\Chart;

use PhpSpreadsheetmaster\src\PhpSpreadsheet\Exception as PhpSpreadsheetException;

class Exception extends PhpSpreadsheetException
{
}
