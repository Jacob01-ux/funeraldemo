<?php

namespace PhpSpreadsheetmaster\src\PhpSpreadsheet\Style\NumberFormat\Wizard;

interface Wizard
{
    public function format(): string;
}
