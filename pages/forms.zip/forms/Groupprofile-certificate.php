<?php
   session_start();
  $policy= $_POST['PolicyNumber'];

   if(isset($_SESSION["id"])){
	// Connect to the database using PDO
	$host = '169.239.218.54';
	$dbname = 'ekhonnec_JeudfraBS';
	$username = 'ekhonnec_JeudfraBS';
	$password = 'JeudfraBS33@';
	
	$dsn = "mysql:host=$host;dbname=$dbname";
	$options = [
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false,
	];
	try {
		$connection = new PDO($dsn, $username, $password, $options);
	} catch (\PDOException $e) {
		throw new \PDOException($e->getMessage(), (int)$e->getCode());
	}
	
	$conn = new mysqli($host, $username, $password, $dbname);
	
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}
	
	$sql = "SELECT * FROM accounts
	WHERE id = '{$_SESSION["id"]}'";
	
	$result = $conn->query($sql);
	
	$u = $result->fetch_assoc();

	$sql1 = "SELECT * FROM groups
	WHERE Registration_Number = '$policy'";
	
	$result = $conn->query($sql1);
	
	$c = $result->fetch_assoc();

	$sql2 = "SELECT * FROM representatives
	WHERE Registration_Number = '$policy'";
	
	$result = $conn->query($sql2);
	
	$s = $result->fetch_assoc();

	//$query = "SELECT * FROM company_keys WHERE c_key = '$company_key'";
	$sql3 = "SELECT Registration_Number FROM groups WHERE Registration_Number ='$policy'";
     
	$stmt3 = $connection->prepare($sql3);
	$stmt3->execute();
	$result3 = $stmt3->fetch(PDO::FETCH_ASSOC);
	
	// Check if the query returned a row
	if ($result3) {
		// Get the Policy value of the last row
		$myValue = $result3['Registration_Number'];
	} else { 
		// Handle the case where no rows were returned
		$myValue = null; // Or set it to some default value
	}
	//retrieving policy number from new clients
	
	// Query 1 - get all policies
	$sql1 = "SELECT * FROM policies";
	$stmt1 = $connection->prepare($sql1);
	$stmt1->execute();
	$result1 = $stmt1->fetchAll(PDO::FETCH_ASSOC);
	
	// Query 2 - get policy count
	$sql2 = "SELECT COUNT(*) AS count FROM groups";
	$stmt2 = $connection->prepare($sql2);
	$stmt2->execute();
	$result2 = $stmt2->fetch(PDO::FETCH_ASSOC);
	$count = $result2['count'];
	
	// Query 3 - get clients with policy MOE0011
	$sql3 = "SELECT * FROM groups WHERE Registration_Number = ?";
	$stmt3 = $connection->prepare($sql3);
	$stmt3->execute([$myValue]);
	$result3 = $stmt3->fetchAll(PDO::FETCH_ASSOC);
     
	// Query 4 - get spouse details for policy MOE0011
	$sql4 = "SELECT * FROM representatives WHERE Registration_Number = ?";
	$stmt4 = $connection->prepare($sql4);
	$stmt4->execute([$myValue]);
	$result4 = $stmt4->fetchAll(PDO::FETCH_ASSOC);
     
     // Query 5 - get additional benefits for policy MOE0011
$sql5 = "SELECT * FROM groups WHERE Registration_Number = ?";
$stmt5 = $connection->prepare($sql5);
$stmt5->execute([$myValue]);
$result5 = $stmt5->fetchAll(PDO::FETCH_ASSOC);
     
	// Query 9 - get all branch details
	$sql9 = "SELECT * FROM branch_details";
	$stmt9 = $connection->prepare($sql9);
	$stmt9->execute();
	$result9 = $stmt9->fetchAll(PDO::FETCH_ASSOC);
	
	// Query 10 - get all branch details (duplicate)
	$sql10= "SELECT * FROM branch_details";
	$stmt10 = $connection->prepare($sql10);
	$stmt10->execute();
	$result10 = $stmt10->fetchAll(PDO::FETCH_ASSOC);
    $pno = 'FD001';
	$_SESSION['my_viriable'] = $myValue;
	}else{
	  header("Location: ../samples/login-2.php");
	}
	?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Funeral demo | Policy certicate</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js "></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
  $(function(){
	$('#tablee').load("table.php");
  })
  $(function(){
	$('#table2').load("table_.php");
  })
</script>
<link href="https://netdna.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
<style type="text/css">
    	body{
background:#eee;
margin-top:20px;
}
.text-danger strong {
        	color: #9f181c;
		}
		.receipt-main {
			background: #ffffff none repeat scroll 0 0;
			border-bottom: 12px solid #333333;
			border-top: 12px solid #9f181c;
			margin-top: 50px;
			margin-bottom: 50px;
			padding: 40px 30px !important;
			position: relative;
			box-shadow: 0 1px 21px #acacac;
			color: #333333;
			font-family: open sans;
		}
		.receipt-main p {
			color: #333333;
			font-family: open sans;
			line-height: 1.42857;
		}
		.receipt-footer h1 {
			font-size: 15px;
			font-weight: 400 !important;
			margin: 0 !important;
		}
		.receipt-main::after {
			background: #414143 none repeat scroll 0 0;
			content: "";
			height: 5px;
			left: 0;
			position: absolute;
			right: 0;
			top: -13px;
		}
		.receipt-main thead {
			background: #414143 none repeat scroll 0 0;
		}
		.receipt-main thead th {
			color:#fff;
      
		}
		.receipt-right h5 {
			font-size: 16px;
			font-weight: bold;
			margin: 0 0 7px 0;
		}
		.receipt-right p {
			font-size: 12px;
			margin: 0px;
		}
		.receipt-right p i {
			text-align: center;
			width: 18px;
		}
		/* .receipt-main td {
			padding: 9px 20px !important;
		}
		.receipt-main th {
			padding: 13px 20px !important;
		}
		.receipt-main td {
			font-size: 13px;
			font-weight: initial !important;
		}
		.receipt-main td p:last-child {
			margin: 0;
			padding: 0;
		}	
		.receipt-main td h2 {
			font-size: 20px;
			font-weight: 900;
			margin: 0;
			text-transform: uppercase;
		} */
		.receipt-header-mid .receipt-left h1 {
			font-weight: 100;
			margin: 34px 0 0;
			text-align: right;
			text-transform: uppercase;
		}
		.receipt-header-mid {
			margin: 24px 0;
			overflow: hidden;
		}
		
		#container {
			background-color: #dcdcdc;
		}
    </style>
</head>
<body>
<div class="col-md-12">
<div class="row" >
<div class="receipt-main col-xs-10 col-sm-10 col-md-6 col-xs-offset-1 col-sm-offset-1 col-md-offset-3" id="print-certificate">
<div class="row">
<div class="receipt-header">
<div class="col-xs-6 col-sm-6 col-md-6">
<div class="receipt-left">
<img class="img-responsive" alt="iamgurdeeposahan" src="download.png" style="width: 91px; border-radius: 43px;">
</div>
</div>
<div class="col-xs-6 col-sm-6 col-md-6 text-right">
<div class="receipt-right">
<h5>Group CERTIFICATE</h5>
  <br><br>
  <?php
// Database connection
$host = '169.239.218.54';
$dbname = 'ekhonnec_JeudfraBS';
$username = 'ekhonnec_JeudfraBS';
$password = 'JeudfraBS33@';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Query to retrieve data from branch_details table
    $query = "SELECT Branch_Name, Email, Address, Contact_Number FROM branch_details";
    $stmt = $conn->prepare($query);
    $stmt->execute();

    // Fetch data and format it
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo '<p style="margin-bottom: -1.5em; margin-top: 0em;"><b></b> ' . $row['Contact_Number'] . '</p>';
        echo '<p style="margin-bottom: 0em; margin-top: 1em;"><b>  </b>' . $row['Email'] . '</p>';
        echo '<p style="margin-bottom: 0em; margin-top: 1em;"><b>   </b>' . $row['Address'] . '</p>';
        echo '<p style="margin-bottom: -1.5em; margin-top: 0em;"><b>  </b>' . $row['Branch_Name'] . '</p>';
    }
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}
?>


      
</div>
</div>
</div>
</div>

<div>
	<label style="display: block; font-weight: bold; color: grey; text-align: center; text-align: center; padding:1%">GROUP-NUMBER: <?= htmlspecialchars($c["Registration_Number"]) ?></label>
<!--Group and Representatives-->

<!-- Group Information -->
<?php if (!empty($result5)) { ?>
  <label style="display: block; font-weight: bold; color: white; background-color: grey; text-align: center;">Group Information</label>
  <table class="table">
    <thead class="thead-light">
      <tr>
        <th scope="col" style="color: white;">Group Name</th>
        <th scope="col" style="color: white;">Number</th>
        <th scope="col" style="color: white;">Email</th>
        <th scope="col" style="color: white;">Group Type</th>
        <th scope="col" style="color: white;">Address</th>
        <th scope="col" style="color: white;">Start Date</th>
        <th scope="col" style="color: white;">Agreement Date</th>
        <th scope="col" style="color: white;">Termination Date</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($result5 as $rows) { ?>
        <tr>
           <td><?= $rows['group_name'] ?></td>
          <td><?= $rows['cellPhone_number'] ?></td>
          <td><?= $rows['email'] ?></td>
          <td><?= $rows['group_type'] ?></td>
          <td><?= $rows['group_address'] ?></td>
          <td><?= $rows['start_date'] ?></td>
          <td><?= $rows['agreement_date'] ?></td>
          <td><?= $rows['termination_date'] ?></td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } ?>

<br/>

<!-- Representatives Information -->
<?php if (!empty($result4)) { ?>
  <label style="display: block; font-weight: bold; color: white; background-color: grey; text-align: center;">Representatives details</label>
  <table class="table">
    <thead class="thead-light">
      <tr>
        <th scope="col" style="color: white;">Name</th>
        <th scope="col" style="color: white;">Mobile</th>
        <th scope="col" style="color: white;">ID Number</th>
        <th scope="col" style="color: white;">Gender</th>
        <th scope="col" style="background-color: grey; color: white; text-align: center;">Role</th>
        <th scope="col" style="color: white;">Agreement Date</th>
        <th scope="col" style="color: white;">Termination Date</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($result4 as $rows) { ?>
        <tr>
          <td><?= $rows['Name'] ?></td>
          <td><?= $rows['Contact_Number'] ?></td>
          <td><?= $rows['_ID'] ?></td>
          <td><?= $rows['Gender'] ?></td>
          <td style="background-color: grey; color: white; text-align: center;"><?= $rows['Role'] ?></td>
          <td><?= $rows['agreement_date'] ?></td>
          <td><?= $rows['termination_date'] ?></td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } ?>




<br/> 
  
  
  

</div>
<div class="row">
<div class="receipt-header receipt-header-mid receipt-footer">
<div class="col-xs-8 col-sm-8 col-md-8 text-left">
<div class="receipt-right">
<p><b>Date :</b> <?php echo date("m/d/Y"); ?></p>
<h5 style="color: rgb(140, 140, 140);">Thank you for choosing us!</h5>
</div>
</div>

<div class="col-xs-4 col-sm-4 col-md-4">
<div class="receipt-left">

</div>
</div>
</div>
</div>
</div>
</div>
<div class="mt-3 text-center">
  <button type="button" id="printcerticate" onclick="printcerticate()" class="btn btn-primary mr-2">Print certicate</button>
  <button type="button" id="downloadcerticate"  onclick="down()" class="btn btn-light">Download</button>
</div>
</div>

<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="https://netdna.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
function printcerticate() {
    var printContents = document.getElementById("print-certificate").innerHTML;
  var originalContents = document.body.innerHTML;
  document.body.innerHTML = printContents;
  window.print();
  document.body.innerHTML = originalContents;
}
function downloadcerticate() {
   alert("workin")
}
window.jsPDF = window.jspdf.jsPDF;
var docPDF = new jsPDF();
function down(){
var elementHTML = document.querySelector("#print-certificate");
docPDF.html(elementHTML, {
 callback: function(docPDF) {
  docPDF.save('policy-certificate.pdf');
 },
 x: 15,
 y: 15,
 width: 170,
 windowWidth: 650
});
}
</script>
</body>
</html>