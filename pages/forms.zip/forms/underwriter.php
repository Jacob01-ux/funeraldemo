<?php

$Month = $_POST['Month'];
$year = $_POST['year'];
$company_name = $_POST['company_name'];
$contact = $_POST['contact'];
$email = $_POST['email'];
$monthly_Premium = $_POST['monthly_Premium'];
$payout_Amount = $_POST['payout_Amount'];
$Policy_Number = $_POST['Policy_Number'];
$policyPlan = $_POST['policyPlan'];



// Connect to the first database
$conn1 = mysqli_connect("169.239.218.54", "ekhonnec_JeudfraBS", "JeudfraBS33@", "ekhonnec_JeudfraBS") or die("Something went wrong");

// Saving and securing data for the "underwriter_details" table
if (isset($_POST['Save'])) {
    // Retrieve POST data and sanitize user inputs
    $Month = filter_var($_POST['Month'], FILTER_SANITIZE_NUMBER_INT);
    $year = filter_var($_POST['year'], FILTER_SANITIZE_NUMBER_INT);
    $company_name = filter_var($_POST['company_name'], FILTER_SANITIZE_STRING);
    $contact = filter_var($_POST['contact'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
    $monthly_Premium = filter_var($_POST['monthly_Premium'], FILTER_SANITIZE_STRING);
    $payout_Amount = filter_var($_POST['payout_Amount'], FILTER_SANITIZE_NUMBER_INT);
    $Policy_Number = filter_var($_POST['Policy_Number'], FILTER_SANITIZE_STRING);
    $policyPlan = filter_var($_POST['policyPlan'], FILTER_SANITIZE_NUMBER_INT);

    // Prepare and execute SQL query
    $stmt1 = $conn1->prepare("INSERT INTO underwriter_details (Month, year, company_name, contact, email, monthly_Premium, payout_Amount, policy_Number, policyPlan) 
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt1->bind_param("sssssssss", $Month, $year, $company_name, $contact, $email, $monthly_Premium, $payout_Amount, $Policy_Number, $policyPlan);
    $stmt1->execute();

    // Check for errors and commit or rollback transaction
    if (!$stmt1->error) {
        mysqli_query($conn1, "COMMIT");
        echo '<script>
            alert("Record successfully added");
            window.location.replace("Underwriter.php");
        </script>';
    } else {
        mysqli_query($conn1, "ROLLBACK");
        echo "Records not added successfully";
    }

    // Close connection and statement
    $stmt1->close();
    $conn1->close();
}

// Connect to the second database
$conn = mysqli_connect("169.239.218.54", "ekhonnec_JeudfraBS", "JeudfraBS33@", "ekhonnec_JeudfraBS") or die("Something went wrong");

// Saving and securing data for the "underwritten" table
if (isset($_POST['AddBtn'])) {
    // Retrieve POST data and sanitize user inputs
    $period = filter_var($_POST['period'], FILTER_SANITIZE_NUMBER_INT);
    $policy_number = filter_var($_POST['policy_number'], FILTER_SANITIZE_STRING);
    $Name_surname = filter_var($_POST['Name_surname'], FILTER_SANITIZE_STRING);
    $Pass_ID = filter_var($_POST['Pass_ID'], FILTER_SANITIZE_NUMBER_INT);
    $underwriter = filter_var($_POST['underwriter'], FILTER_SANITIZE_STRING);
    $underwriterPlan = filter_var($_POST['underwriterPlan'], FILTER_SANITIZE_NUMBER_INT);
    $cover_Amount = filter_var($_POST['cover_Amount'], FILTER_SANITIZE_NUMBER_INT);

    // Prepare and execute SQL query
    $stmt = $conn->prepare("INSERT INTO underwritten (period, policy_number, Name_surname, Pass_ID, underwriter, underwriterPlan, cover_amount) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $period, $policy_number, $Name_surname, $Pass_ID, $underwriter, $underwriterPlan, $cover_Amount);
    $stmt->execute();

    // Check for errors and commit or rollback transaction
    if (!$stmt->error) {
        mysqli_query($conn, "COMMIT");
        echo '<script>
            alert("Record successfully added");
            window.location.replace("Cash_Book.html");
        </script>';
    } else {
        mysqli_query($conn, "ROLLBACK");
        echo "Records not added successfully";
    }

    // Close connection and statement
    $stmt->close();
    $conn->close();
}
?>
