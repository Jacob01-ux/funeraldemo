<?php
session_start();
// Connect to the database
$host = '169.239.218.54';
$dbname = 'ekhonnec_JeudfraBS';
$username = 'ekhonnec_JeudfraBS';
$password = 'JeudfraBS33@';

$dsn = "mysql:host=$host;dbname=$dbname";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];
try {
    $connection = new PDO($dsn, $username, $password, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Saving and Securing Data
if (isset($_POST['Save'])) {
    // Retrieve POST data and sanitize user inputs
    $Name_and_Surname = filter_var($_POST['Name_and_Surname'], FILTER_SANITIZE_STRING);
    $ID_ = filter_var($_POST['ID_'], FILTER_SANITIZE_NUMBER_INT);
    $Company_name = filter_var($_POST['Company_name'], FILTER_SANITIZE_STRING);
    $Company_telephone = filter_var($_POST['Company_telephone'], FILTER_SANITIZE_NUMBER_INT);
    $Physical_Address = filter_var($_POST['Physical_Address'], FILTER_SANITIZE_STRING);
    $Email_Address = filter_var($_POST['Email_Address'], FILTER_SANITIZE_STRING);
    $type = filter_var($_POST['type'], FILTER_SANITIZE_STRING);

    // Prepare and execute SQL query
    $stmt = $conn->prepare("INSERT INTO phonebook (Name_and_Surname, ID_, Company_name, Company_telephone, Physical_Address, Email_Address, type) 
                         VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $Name_and_Surname, $ID_, $Company_name, $Company_telephone, $Physical_Address, $Email_Address, $type);
    $stmt->execute();

    // Check for errors and commit or rollback transaction
    if ($stmt->error) {
        mysqli_query($conn, "ROLLBACK");
        echo "Records not added successfully";
    } else {
        mysqli_query($conn, "COMMIT");
        echo '<script>
        alert("Record successfully added");
        window.location.replace("phonebook.php");
    </script>';
    }

    // Close connection and statement
    $stmt->close();
    $conn->close();
}
?>