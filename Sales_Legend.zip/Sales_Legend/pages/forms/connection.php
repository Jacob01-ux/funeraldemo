
<?php

 // Connect to the database
 $connection=mysqli_connect("169.239.218.54", "ekhonnec_JeudfraBS", "JeudfraBS33@", "ekhonnec_JeudfraBS") or die("something wrong happend");
?>