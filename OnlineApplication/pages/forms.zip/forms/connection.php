
<?php

 // Connect to the database
 $connection=mysqli_connect("169.239.218.54", "ekhonnec_Eyomusa_Funeral", "websystems_10", "ekhonnec_Eyomusa_Funeral") or die("something wrong happend");
?>