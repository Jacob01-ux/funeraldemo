<?php
session_start();


if(!isset($_SESSION['unique_key'])){
        header("Location: ../samples/login-2.php");

  }






?>