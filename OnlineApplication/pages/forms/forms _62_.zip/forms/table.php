<?php
session_start(); // this NEEDS TO BE AT THE TOP of the page before any output etc
//echo $_SESSION['superhero'];
//database connection
$host = "169.239.218.54";
$dbname = "ekhonnec_vakhandli_group";
$username = "ekhonnec_vakhandli_group";
$password = "vakhandli_group";

$dsn = "mysql:host=$host;dbname=$dbname";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];
try {
    $connection = new PDO($dsn, $username, $password, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM accounts
WHERE id = '{$_SESSION["id"]}'";

$result = $conn->query($sql);

$u = $result->fetch_assoc();

$sql3 = "SELECT Policy FROM clients ORDER BY id DESC LIMIT 1";
$stmt3 = $connection->prepare($sql3);
$stmt3->execute();
$result3 = $stmt3->fetch(PDO::FETCH_ASSOC);

// Check if the query returned a row
if ($result3) {
    // Get the Policy value of the last row
    $myValue = $result3['Policy'];
} else { 
    // Handle the case where no rows were returned
    $myValue = null; // Or set it to some default value
}
//retrieving policy number from new clients


// Query 1 - get all policies
$sql1 = "SELECT * FROM policies";
$stmt1 = $connection->prepare($sql1);
$stmt1->execute();
$result1 = $stmt1->fetchAll(PDO::FETCH_ASSOC);


// Query 2 - get policy count
$sql2 = "SELECT COUNT(*) AS count FROM policies";
$stmt2 = $connection->prepare($sql2);
$stmt2->execute();
$result2 = $stmt2->fetch(PDO::FETCH_ASSOC);
$count = $result2['count'];

// Query 3 - get clients with policy MOE0011
$sql3 = "SELECT * FROM clients WHERE Policy = ?";
$stmt3 = $connection->prepare($sql3);
$stmt3->execute([$myValue]);
$result3 = $stmt3->fetchAll(PDO::FETCH_ASSOC);
$polName = "";
$groName = "";
foreach ($result3 as $rows) {
    $polName = $rows['Package'];
    $groName = $rows['Group_Name'];
}

// Query 4 - get spouse details for policy MOE0011
$sql4 = "SELECT * FROM spousedetails WHERE Policy = ?";
$stmt4 = $connection->prepare($sql4);
$stmt4->execute([$myValue]);
$result4 = $stmt4->fetchAll(PDO::FETCH_ASSOC);

// Query 5 - get additional benefits for policy MOE0011
$sql5 = "SELECT * FROM members_additional_benefits WHERE Policy_Number = ?";
$stmt5 = $connection->prepare($sql5);
$stmt5->execute([$myValue]);
$result5 = $stmt5->fetchAll(PDO::FETCH_ASSOC);

// Query 6 - get beneficiaries for policy MOE0011
$sql6 = "SELECT * FROM beneficiaries WHERE Policy_number = ?";
$stmt6 = $connection->prepare($sql6);
$stmt6->execute([$myValue]);
$result6 = $stmt6->fetchAll(PDO::FETCH_ASSOC);

// Query 7 - get additional members for policy MOE0011
$sql7 = "SELECT * FROM additional_members WHERE Policy_Number = ?";
$stmt7 = $connection->prepare($sql7);
$stmt7->execute([$myValue]);
$result7 = $stmt7->fetchAll(PDO::FETCH_ASSOC);

// Query 8 - get policy by policy name and group name
$sql8 = "SELECT * FROM policies WHERE Policy_Name = ? AND Group_name = ?";
$stmt8 = $connection->prepare($sql8);
$stmt8->execute([$polName, $groName]);
$result8 = $stmt8->fetchAll(PDO::FETCH_ASSOC);

// Query 9 - get all branch details
$sql9 = "SELECT * FROM branch_details";
$stmt9 = $connection->prepare($sql9);
$stmt9->execute();
$result9 = $stmt9->fetchAll(PDO::FETCH_ASSOC);

// Query 10 - get all branch details (duplicate)
$sql10= "SELECT * FROM branch_details";
$stmt10 = $connection->prepare($sql10);
$stmt10->execute();
$result10 = $stmt10->fetchAll(PDO::FETCH_ASSOC);

$mysqli = new mysqli(hostname: $host,
                     username: $username, 
                     password: $password, 
                     database: $dbname);

//check connection error
if ($mysqli->connect_errno) {
    die("Connection error: " . $mysqli-connect_error);
}

$sql2 = "SELECT * 
FROM beneficiaries
WHERE Policy_Number = '$myValue'";

$result1 = $mysqli->query($sql2);
$result2 = $mysqli->query($sql2);
$result3 = $mysqli->query($sql2);
if (!$result2) {
die("Invalid query: " . $mysqli->error);
}

?>
<?php if($result1->num_rows > 0): ?>
<table class="table">
    <thead class="thead-light">
      <tr>
        <th scope="col">Name(s)</th>
        <th scope="col">Surname</th>
        <th scope="col">ID</th>
      </tr>
    </thead>
    <tbody>
    <?php
                                                   //  $mysql = require __DIR__ . "/../database.php";
                                                   //Readd all row from database


                                                   //read data of each row
                                                   ?>                                             
      <tr>
        <td><?php while($row = $result1->fetch_assoc()){ echo "<p style='margin-bottom: -1.5em;  margin-top: 0em;'>$row[Name]</p><br/> ";} ?></td>
        <td><?php while($row = $result2->fetch_assoc()){ echo "<p style='margin-bottom: -1.5em;  margin-top: 0em;'>$row[surname]</p><br/> ";} ?></td>
        <td><?php while($row = $result3->fetch_assoc()){ echo "<p style='margin-bottom: -1.5em;  margin-top: 0em;'>$row[_ID]</p><br/> ";} ?></td>
      </tr>
    </tbody>
  </table>
  <?php else: ?>
				<h5 style="margin-bottom: 0em;  margin-top: 1em; font-size: smaller"><b>:NONE</b></h5>
      <?php endif; ?>