
<?php

 // Connect to the database
 $connection=mysqli_connect("169.239.218.54", "ekhonnec_vakhandli_group", "vakhandli_group", "ekhonnec_vakhandli_group") or die("something wrong happend");
?>